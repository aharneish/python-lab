# Notes for Optimization Techniques

You can find the notes of the course for Optimization Techniques!!

## Topics

- Classical Optimization
- Non-Linear Optimization
- Liner Optimization
  - Graphical Method 
  - Simplex Method 

